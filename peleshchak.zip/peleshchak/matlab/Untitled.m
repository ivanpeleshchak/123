[X,Y]=meshgrid(0.000000000001:0.001:1);
Z=X*Y;
mesh(X,Y,Z)